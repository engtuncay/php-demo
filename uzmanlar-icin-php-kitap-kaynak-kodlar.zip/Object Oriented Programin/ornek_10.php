<?php 
class a{ 
     
} 
class b extends a { 
     
} 
final class c extends b { 
     
} 
$c = new c(); 
?>