<?php 
$SMARTY =& Loader::loadClass("Smarty"); 
?>
