<?php
$this->assign('name','Mert'); 
$arr = array(1,2,3,4,5); 
$this->assign('arr',$arr); 

$this->display('deneme2.tpl'); 
?>
