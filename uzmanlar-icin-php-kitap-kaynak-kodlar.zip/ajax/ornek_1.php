<?php
if($_POST['isim'])
  echo "Merhaba <b>{$_POST['isim']}</b>";
else 
  echo -1;
?>
