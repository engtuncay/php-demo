<?php 
$arr=array( 
           'isimler'=>array('Mehmet','Taha','Ülkü'), 
           'js'=>array('jsFunction'=>'parsing') 
           ); 
echo json_encode($arr); 
?>
