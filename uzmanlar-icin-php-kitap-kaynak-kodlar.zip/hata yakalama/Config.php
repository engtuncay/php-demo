<?php
class Config {
	const CHARACTER_SET = 'UTF-8';
}